var joinClasses = function(classes) {
  return classes.join(' ');
};

exports.joinClasses = joinClasses;
