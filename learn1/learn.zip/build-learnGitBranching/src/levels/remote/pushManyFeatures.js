exports.level = {
  "goalTreeString": "%7B%22branches%22%3A%7B%22master%22%3A%7B%22target%22%3A%22C7%27%22%2C%22id%22%3A%22master%22%2C%22remoteTrackingBranchID%22%3A%22o/master%22%2C%22localBranchesThatTrackThis%22%3Anull%7D%2C%22o/master%22%3A%7B%22target%22%3A%22C7%27%22%2C%22id%22%3A%22o/master%22%2C%22remoteTrackingBranchID%22%3Anull%2C%22localBranchesThatTrackThis%22%3A%5B%22master%22%5D%7D%2C%22side1%22%3A%7B%22target%22%3A%22C2%27%22%2C%22id%22%3A%22side1%22%2C%22remoteTrackingBranchID%22%3Anull%2C%22localBranchesThatTrackThis%22%3Anull%7D%2C%22side2%22%3A%7B%22target%22%3A%22C4%27%22%2C%22id%22%3A%22side2%22%2C%22remoteTrackingBranchID%22%3Anull%2C%22localBranchesThatTrackThis%22%3Anull%7D%2C%22side3%22%3A%7B%22target%22%3A%22C7%27%22%2C%22id%22%3A%22side3%22%2C%22remoteTrackingBranchID%22%3Anull%2C%22localBranchesThatTrackThis%22%3Anull%7D%7D%2C%22commits%22%3A%7B%22C0%22%3A%7B%22parents%22%3A%5B%5D%2C%22id%22%3A%22C0%22%2C%22rootCommit%22%3Atrue%7D%2C%22C1%22%3A%7B%22parents%22%3A%5B%22C0%22%5D%2C%22id%22%3A%22C1%22%7D%2C%22C2%22%3A%7B%22parents%22%3A%5B%22C1%22%5D%2C%22id%22%3A%22C2%22%7D%2C%22C3%22%3A%7B%22parents%22%3A%5B%22C1%22%5D%2C%22id%22%3A%22C3%22%7D%2C%22C4%22%3A%7B%22parents%22%3A%5B%22C3%22%5D%2C%22id%22%3A%22C4%22%7D%2C%22C5%22%3A%7B%22parents%22%3A%5B%22C1%22%5D%2C%22id%22%3A%22C5%22%7D%2C%22C6%22%3A%7B%22parents%22%3A%5B%22C5%22%5D%2C%22id%22%3A%22C6%22%7D%2C%22C7%22%3A%7B%22parents%22%3A%5B%22C6%22%5D%2C%22id%22%3A%22C7%22%7D%2C%22C8%22%3A%7B%22parents%22%3A%5B%22C1%22%5D%2C%22id%22%3A%22C8%22%7D%2C%22C2%27%22%3A%7B%22parents%22%3A%5B%22C8%22%5D%2C%22id%22%3A%22C2%27%22%7D%2C%22C3%27%22%3A%7B%22parents%22%3A%5B%22C2%27%22%5D%2C%22id%22%3A%22C3%27%22%7D%2C%22C4%27%22%3A%7B%22parents%22%3A%5B%22C3%27%22%5D%2C%22id%22%3A%22C4%27%22%7D%2C%22C5%27%22%3A%7B%22parents%22%3A%5B%22C4%27%22%5D%2C%22id%22%3A%22C5%27%22%7D%2C%22C6%27%22%3A%7B%22parents%22%3A%5B%22C5%27%22%5D%2C%22id%22%3A%22C6%27%22%7D%2C%22C7%27%22%3A%7B%22parents%22%3A%5B%22C6%27%22%5D%2C%22id%22%3A%22C7%27%22%7D%7D%2C%22HEAD%22%3A%7B%22target%22%3A%22master%22%2C%22id%22%3A%22HEAD%22%7D%2C%22originTree%22%3A%7B%22branches%22%3A%7B%22master%22%3A%7B%22target%22%3A%22C7%27%22%2C%22id%22%3A%22master%22%2C%22remoteTrackingBranchID%22%3Anull%2C%22localBranchesThatTrackThis%22%3Anull%7D%7D%2C%22commits%22%3A%7B%22C0%22%3A%7B%22parents%22%3A%5B%5D%2C%22id%22%3A%22C0%22%2C%22rootCommit%22%3Atrue%7D%2C%22C1%22%3A%7B%22parents%22%3A%5B%22C0%22%5D%2C%22id%22%3A%22C1%22%7D%2C%22C8%22%3A%7B%22parents%22%3A%5B%22C1%22%5D%2C%22id%22%3A%22C8%22%7D%2C%22C2%27%22%3A%7B%22parents%22%3A%5B%22C8%22%5D%2C%22id%22%3A%22C2%27%22%7D%2C%22C3%27%22%3A%7B%22parents%22%3A%5B%22C2%27%22%5D%2C%22id%22%3A%22C3%27%22%7D%2C%22C4%27%22%3A%7B%22parents%22%3A%5B%22C3%27%22%5D%2C%22id%22%3A%22C4%27%22%7D%2C%22C5%27%22%3A%7B%22parents%22%3A%5B%22C4%27%22%5D%2C%22id%22%3A%22C5%27%22%7D%2C%22C6%27%22%3A%7B%22parents%22%3A%5B%22C5%27%22%5D%2C%22id%22%3A%22C6%27%22%7D%2C%22C7%27%22%3A%7B%22parents%22%3A%5B%22C6%27%22%5D%2C%22id%22%3A%22C7%27%22%7D%7D%2C%22HEAD%22%3A%7B%22target%22%3A%22master%22%2C%22id%22%3A%22HEAD%22%7D%7D%7D",
  "solutionCommand": "git fetch;git rebase o/master side1;git rebase side1 side2;git rebase side2 side3;git rebase side3 master;git push",
  "startTree": "{\"branches\":{\"master\":{\"target\":\"C1\",\"id\":\"master\",\"remoteTrackingBranchID\":\"o/master\",\"localBranchesThatTrackThis\":null},\"o/master\":{\"target\":\"C1\",\"id\":\"o/master\",\"remoteTrackingBranchID\":null,\"localBranchesThatTrackThis\":[\"master\"]},\"side1\":{\"target\":\"C2\",\"id\":\"side1\",\"remoteTrackingBranchID\":null,\"localBranchesThatTrackThis\":null},\"side2\":{\"target\":\"C4\",\"id\":\"side2\",\"remoteTrackingBranchID\":null,\"localBranchesThatTrackThis\":null},\"side3\":{\"target\":\"C7\",\"id\":\"side3\",\"remoteTrackingBranchID\":null,\"localBranchesThatTrackThis\":null}},\"commits\":{\"C0\":{\"parents\":[],\"id\":\"C0\",\"rootCommit\":true},\"C1\":{\"parents\":[\"C0\"],\"id\":\"C1\"},\"C2\":{\"parents\":[\"C1\"],\"id\":\"C2\"},\"C3\":{\"parents\":[\"C1\"],\"id\":\"C3\"},\"C4\":{\"parents\":[\"C3\"],\"id\":\"C4\"},\"C5\":{\"parents\":[\"C1\"],\"id\":\"C5\"},\"C6\":{\"parents\":[\"C5\"],\"id\":\"C6\"},\"C7\":{\"parents\":[\"C6\"],\"id\":\"C7\"}},\"HEAD\":{\"target\":\"side3\",\"id\":\"HEAD\"},\"originTree\":{\"branches\":{\"master\":{\"target\":\"C8\",\"id\":\"master\",\"remoteTrackingBranchID\":null,\"localBranchesThatTrackThis\":null}},\"commits\":{\"C0\":{\"parents\":[],\"id\":\"C0\",\"rootCommit\":true},\"C1\":{\"parents\":[\"C0\"],\"id\":\"C1\"},\"C8\":{\"parents\":[\"C1\"],\"id\":\"C8\"}},\"HEAD\":{\"target\":\"master\",\"id\":\"HEAD\"}}}",
  "hint": {
    "en_US": "Remember you can always use the undo or reset commands",
    "zh_CN": "你随时都可以使用 undo 或 reset 命令。",
    "zh_TW": "你隨時都可以使用 undo 或 reset 指令。",
    "es_AR": "Acordate que siempre podés usar los comandos reset y undo",
    "es_ES": "Recuerda que siempre puedes usar los comandos reset y undo",
    "pt_BR": "Lembre-se que você sempre pode usar undo ou reset",
    "gl"   : "Lembra que sempre podes usar undo ou reset",
    "de_DE": "Denk dran, du kannst immer undo oder reset benutzen, um deine Befehle zurück zu nehmen.",
    "ja"   : "undoやresetコマンドをいつでも使用することができるのをお忘れなく",
    "fr_FR": "Rappelez-vous que vous pouvez toujours utiliser les commandes undo et reset.",
    "ru_RU": "Помни - ты всегда можешь отменить команды с помощью undo или reset",
    "ko"   : "명령어를 undo와 reset으로 되돌릴 수 있다는 것을 잊지마세요",
    "uk"   : "Пам'ятай, ти в будь-який момент можеш використовувати команди undo або reset",
    "vi"   : "Nhớ rằng bạn luôn luôn có thể hoàn tác hoặc soạn lại câu lệnh ",
    "sl_SI": "Vedno lahko razveljaviš ukaz ali ponastaviš stopnjo."
  },
  "name": {
    "en_US": "Push Master!",
    "zh_CN": "推送主分支",
    "zh_TW": "push master！",
    "es_AR": "¡Push Master!",
    "es_ES": "¡Push Master!",
    "pt_BR": "Push Master!",
    "gl"   : "Empurra ó Master!",
    "de_DE": "Push Master!",
    "ja"   : "Push Master!",
    "fr_FR": "Maître du push !",
    "ru_RU": "Push Мастер!",
    "ko"   : "Push Master!",
    "uk"   : "Push Maйстер!",
    "vi"   : "Push Master!",
    "sl_SI": "Push Master!"
  },
  "compareOnlyMasterHashAgnostic": true,
  "startDialog": {
    "en_US": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Merging feature branches",
              "",
              "Now that you're comfortable with fetching, pulling, and pushing, lets put these skills to the test with a new workflow.",
              "",
              "It's common for developers on big projects to do all their work on feature branches (off of `master`) and then integrate that work only once it's ready. This is similar to the previous lesson (where side branches get pushed to the remote), but here we introduce one more step.",
              "",
              "Some developers only push and pull when on the `master` branch -- that way `master` always stays updated to what is on the remote (`o/master`).",
              "",
              "So for this workflow we combine two things:",
              "",
              "* integrating feature branch work onto `master`, and",
              "* pushing and pulling from the remote"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Let's see a refresher real quick of how to update `master` and push work."
            ],
            "afterMarkdowns": [
              "We executed two commands here that:",
              "",
              "* rebased our work onto new commits from remote, and",
              "* published our work to the remote"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "This level is pretty hefty -- here is the general outline to solve:",
              "",
              "* There are three feature branches -- `side1` `side2` and `side3`",
              "* We want to push each one of these features, in order, to the remote",
              "* The remote has since been updated, so we will need to incorporate that work as well",
              "",
              ":O intense! good luck, completing this level is a big step."
            ]
          }
        }
      ]
    },
    "fr_FR": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Fusionner les feature branches",
              "",
              "Maintenant que vous êtes habitué à fetch, pull et push, mettons ces compétences à profit avec une autre approche de travail.",
              "",
              "Il est commun pour les développeurs de gros projets de faire tout leur travail dans des \"feature branches\" dédiées à une fonctionnalité (en dehors de `master`) et d'intégrer ce travail au reste seulement une fois qu'il est prêt. C'est similaire à la leçon précédente (où les branches secondaires étaient pushées sur le dépôt distant), mais ici nous introduisons une étape supplémentaire.",
              "",
              "Certains développeurs utilisent la méthode \"push puis pull\" uniquement sur la branche `master` : de cette manière `master` reste toujours à jour avec ce qu'il y a sur le dépôt distant (`o/master`).",
              "",
              "Cette approche combine donc deux choses :",
              "",
              "* intégrer le travail présent depuis la feature branch (la fonctionnalité développée) vers `master`, puis",
              "* pusher et puller sur le dépôt distant."
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Rappelons-nous rapidement comment mettre à jour `master` et envoyer (push) le travail."
            ],
            "afterMarkdowns": [
              "Nous exécutons ici deux commandes :",
              "",
              "* on rebase notre travail sur de nouveaux commits, puis",
              "* on publie notre travail sur le dépôt distant"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Ce niveau est assez conséquent; voici l'idée générale de la solution :",
              "",
              "* Il y a trois feature branches : `side1` `side2` et `side3`",
              "* Nous voulons envoyer chacune de ces modifications, dans l'ordre, sur le dépôt distant",
              "* Le dépôt distant a été mis à jour entre-temps, donc nous avons aussi besoin d'intégrer ce travail",
              "",
              ":O difficile ! bonne chance, finir ce niveau est une grande étape."
            ]
          }
        }
      ]
    },
    "es_AR": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Mergeando feature branches",
              "",
              "Ahora que estás cómodo fetcheando, pulleando y pusheando, pongamos a prueba estas habilidades con un nuevo flujo de trabajo.",
              "",
              "Es bastante común que los desarrolladores en los grandes proyectos trabajen sobre ramas específicas para cada tarea (feature branches) basadas en `master`, y que las integren sólo cuando están listas. Esto es similar a la lección anterior, en que pusheabamos las ramas periféricas al remoto, pero acá tenemos un paso más.",
              "",
              "Algunos desarrolladores sólo pushean y pullean cuando están en `master`: de ese modo, `master` siempre se mantiene actualizado con el remoto (`o/master`).",
              "",
              "Entonces, en este flujo de trabajo combinamos dos cosas:",
              "",
              "* integramos el trabajo de las ramas específicas a `master`, y",
              "* pusheamos y pulleamos del remoto"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Refresquemos un poco cómo actualizar `master` y pushear nuestro trabajo."
            ],
            "afterMarkdowns": [
              "Acá ejecutamos dos comandos que:",
              "",
              "* rebasearon nuestro trabajo sobre los nuevos commits del remoto, y",
              "* publicamos nuestro trabajo en ese remoto"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Este nivel es bastante pesado. Acá tenés algunos lineamientos para resolverlo:",
              "",
              "* Tenemos tres ramas específicas -- `side1` `side2` and `side3`",
              "* Queremos pushear cada una de esas ramas, en orden, al remoto",
              "* El remoto fue actualizado, así que vamos a tener que integrar esos cambios también",
              "",
              ":O ¡Intenso! ¡Éxitos! Completar este nivel representa un gran avance."
            ]
          }
        }
      ]
    },
    "es_ES": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Haciendo merge con ramas de trabajo",
              "",
              "Ahora que estás cómodo fetcheando, pulleando y pusheando, pongamos a prueba estas habilidades con un nuevo flujo de trabajo.",
              "",
              "Es bastante común que los desarrolladores en los grandes proyectos trabajen sobre ramas específicas para cada tarea (feature branches o ramas de trabajo) basadas en `master`, y que las integren sólo cuando estén listas. Esto es similar a la lección anterior, en la que hicimos push de las ramas periféricas al remoto, pero aquí tenemos un paso más.",
              "",
              "Algunos desarrolladores sólo pushean y pullean cuando están en `master`: de ese modo, `master` siempre se mantiene actualizado con el remoto (`o/master`).",
              "",
              "Entonces, en este flujo de trabajo combinamos dos cosas:",
              "",
              "* integramos el trabajo de las ramas específicas a `master`, y",
              "* pusheamos y pulleamos del remoto"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Refresquemos un poco cómo actualizar `master` y pushear nuestro trabajo."
            ],
            "afterMarkdowns": [
              "Ahora ejecutamos dos comandos que:",
              "",
              "* rebasearon nuestro trabajo sobre los nuevos commits del remoto, y",
              "* publicamos nuestro trabajo en ese remoto"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Este nivel es bastante pesado. Aquí tienes algunas ideas para resolverlo:",
              "",
              "* Tenemos tres ramas específicas -- `side1` `side2` and `side3`",
              "* Queremos hacer push de cada una de esas ramas, en orden, al remoto",
              "* El remoto fue actualizado, así que vamos a tener que integrar esos cambios también",
              "",
              ":O ¡Genial! ¡Éxito! Completar este nivel representa un gran avance."
            ]
          }
        }
      ]
    },
    "pt_BR": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Merge de ramos de funcionalidades",
              "",
              "Agora que você está confortável com fetch, pull e push, vamos colocar essas habilidades em teste com um novo fluxo de trabalho.",
              "",
              "É comum para desenvolvedores de grande projetos fazer todo o trabalho em ramos de funcionalidades (fora do `master`) e então integrar esse trabalho uma única vez quando ele estiver pronto. Isso é similar à lição anterior (onde ramos laterais eram enviados ao repositório remoto), mas introduzimos mais um passo.",
              "",
              "Alguns desenvolvedores só fazem push e pull quando no ramo `master` -- desta forma o `master` sempre se mantém atualizado com aquilo que está no ramo remoto (`o/master`).",
              "",
              "Então, para este fluxo de trabalho, combinaremos duas coisas:",
              "",
              "* Integrar ramos de funcionalidade no `master`, e",
              "* Realizar push e pull do repositório remoto"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Vamos refrescar a memória sobre como atualizar o `master` e enviar trabalho."
            ],
            "afterMarkdowns": [
              "Nós executamos dois comandos aqui que:",
              "",
              "* Fizeram rebase de nosso trabalho nos novos commits do repositório remoto, e",
              "* Publicaram nosso trabalho no repositório remoto"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Esse nível é um pouco pesado -- aqui está a linha geral de como resolver:",
              "",
              "* Há três ramos de funcionalidades -- `side1`, `side2` e `side3`",
              "* Queremos enviar cada uma dessas funcionalidades, em ordem, para o repositório remoto",
              "* O repositório remoto foi atualizado desde então, então também precisaremos incorporar o trabalho realizado lá",
              "",
              ":O intenso! boa sorte, completar este nível é um grande passo."
            ]
          }
        }
      ]
    },
    "gl": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Mesturando ramas",
              "",
              "Agora que estás afeito a descargar, mesturar e empurrar, poñamos a proba estas habilidades cun novo fluxo de traballo.",
              "",
              "É bastante común que os desenvolvedores nos grandes proxectos traballen sobre ramas específicas para cada tarefa (feature branches) baseadas en `mater`, e que as integren só cando están preparadas. Esto é similar á lección anterior, na que empurrábamos as ramas periféricas ó remoto, pero acá temos un paso máis.",
              "",
              "Algúns desenvovledores só empurran e descargan cando están en `master`: de ese xeito, `master` sempre mantén actualizado o seu estado co remoto (`o/master`).",
              "",
              "Entón, neste fluxo de traballo combinamos dúas cousas:",
              "",
              "* integramos o traballo das ramas específicas a `master`, e",
              "* empurramos e turramos do remoto"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Refresquemos un pouco cómo actualizar `master` e empurrar o noso traballo."
            ],
            "afterMarkdowns": [
              "Agora executamos dous comandos que:",
              "",
              "* rebasamos o noso traballo sobre os novos commits do remoto, e",
              "* publicamos o noso traballo nese remoto"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Este nivel é bastante pesado. Aquí tes algúns patróns para resolvelo:",
              "",
              "* Temos tres ramas específicas -- `side1` `side2` e `side3`",
              "* Queremos empurrar cada unha de esas ramas, en orde, ó remoto",
              "* O remoto foi actualizado, así que imos ter que integrar eses cambios tamén",
              "",
              ":O ¡Intenso! ¡Éxitos! Completar este nivel representa un grande avance."
            ]
          }
        }
      ]
    },
    "zh_TW": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## merge feature branch",
              "",
              "現在你已經很熟悉 fetch、pull 以及 push，讓我們來針對一個新的問題來應用這些技巧。",
              "",
              "在一個大型的專案裡面，程式設計師經常會在 feature branch（有別於 master branch）上面做開發，之後等開發完之後，在一次 merge 回去。這跟之前的課程是很類似的（其它的 branch 被 push 到 remote），但是現在我們還要再多介紹一個步驟。",
              "",
              "某些程式設計師只針對 `master` branch 進行 push 或者是 pull。這樣子的話 `master` 一直都保持跟 remote （`o/master`） 同步。",
              "",
              "所以針對這個問題我們結合了兩件事情：",
              "",
              "* merge feature branch 到`master` branch，並且",
              "* push remote 以及 pull remote"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "讓我們馬上來實際看一下如何更新 `master` 並且 push 到 remote。"
            ],
            "afterMarkdowns": [
              "我們在這裡執行兩個指令:",
              "",
              "* rebase 我們的 branch 到 remote 的新的 commit 上面，並且",
              "* 發佈到 remote 上面"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "這個關卡很複雜，這裡有一些提示：",
              "",
              "* 總共有三個 feature branch，分別是 `side1`，`side2` 以及 `side3`",
              "* 我們想要將這三個 branch 分別 push 到 remote。",
              "* 但是 remote 已經被事先更新過了，所以我們必須要先同步那些更新。",
              "",
              ":O 很好！祝你好運，完成這個關卡是一個很重要的步驟。"
            ]
          }
        }
      ]
    },
    "de_DE": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Einen Feature Branch reintegrieren",
              "",
              "Nun da du mit `fetch`, `pull`, und `push` vertraut bist sollten wir diese Fähigkeiten mit einem neuen Arbeitsablauf auf die Probe stellen.",
              "",
              "Für Entwickler in großen Projekten ist es nicht ungewöhnlich ihre Arbeit in Feature Branches (von `master` abgeleitet) zu erledigen und dann diese Inhalte zu reintegrieren, wenn sie fertig sind. Das ist ähnlich dem vorherigen Level (in dem ein Feature Branch auf den Server geschoben wird), nur mit einem zusätzlichen Schritt.",
              "",
              "Einige Entwickler pushen und pullen nur auf dem `master` -- dadurch ist `master` immer aktuell zu seinem Gegenstück auf dem Server (`o/master`).",
              "",
              "Für diesen Ablauf werden wir also zwei Dinge kombinieren:",
              "",
              "* einen Feature Branch in `master` reintegrieren und",
              "* vom entfernten Server pushen und pullen."
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Schauen wir uns zur Erinnerung schnell noch mal an wie man den `master` aktualisiert und seine Commits pusht."
            ],
            "afterMarkdowns": [
              "Wir haben hier zwei Befehle ausgeführt, die:",
              "",
              "* unsere Commits auf die neuen Commits vom Server gepackt und",
              "* unsere Commits zum Server gepusht haben."
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Dieser Level ist ziemlich heftig -- hier ist im Groben der Weg:",
              "",
              "* Es gibt drei Feature Branches -- `side1`, `side2` und `side3`.",
              "* Wir möchten jedes dieser Features, in dieser Reihenfolge, auf den Server bringen.",
              "* Der Server hat Commits, die wir noch nicht haben, diese müssen also bei uns integriert werden.",
              "",
              ":O Krass! Viel Erfolg, diesen Level zu schaffen ist ein großer Schritt."
            ]
          }
        }
      ]
    },
    "zh_CN":{
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## 合并特性分支",
              "",
              "既然你应该很熟悉 fetch、pull、push 了，现在我们要通过一个新的工作流来测试你的这些技能。",
              "",
              "在大型项目中开发人员通常会在（从 `master` 上分出来的）特性分支上工作，工作完成后只做一次集成。这跟前面课程的描述很相像（把 side 分支推送到远程仓库），不过本节我们会深入一些.",
              "",
              "但是有些开发人员只在 master 上做 push、pull —— 这样的话 master 总是最新的，始终与远程分支 (o/master) 保持一致。",
              "",
              "对于接下来这个工作流，我们集成了两个步骤：",
              "",
              "* 将特性分支集成到 `master` 上",
              "* 推送并更新远程分支"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "让我们看看如何快速的更新 `master` 分支并推送到远程。"
            ],
            "afterMarkdowns": [
              "我们执行了两个命令: ",
              "",
              "* 将我们的工作 rebase 到远程分支的最新提交记录",
              "* 向远程仓库推送我们的工作"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "这个关卡的 Boss 很厉害 —— 以下是通关提示：",
              "",
              "* 这里共有三个特性分支 —— `side1` `side2` 和 `side3`",
              "* 我需要将这三分支按顺序推送到远程仓库",
              "* 因为远程仓库已经被更新过了，所以我们还要把那些工作合并过来",
              "",
              ":O 紧张了？祝你好运！完成了本关, 你就向目标又迈近了一大步啦！"
            ]
          }
        }
      ]
    },
    "ru_RU": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Слияние фича-бранчей (веток)",
              "",
              "Теперь, когда вы умело владеете командами fetch, pull и push, давайте применим эти навыки в сочетании с новым рабочим процессом (он же workflow).",
              "",
              "Среди разработчиков, вовлечённых в большой проект, довольно распространённ приём — выполнять всю свою работу в так называемых фича-бранчах (вне `master`). А затем, как только работа выполнена, разработчик интегрирует всё, что было им сделано. Всё это, за исключением одного шага, похоже на предыдущий урок (там, где мы закачивали ветки на удалённый репозиторий)",
              "",
              "Ряд разработчиков делают push и pull лишь на локальную ветку `master` - таким образом ветка `master` всегда синхронизирована с тем, что находится на удалённом репозитории (`o/master`).",
              "",
              "Для этого рабочего процесса мы совместили две вещи:",
              "",
              "* интеграцию фича-бранчей в `master`",
              "* закачку (push) и скачку (pull) с удалённого репозитория"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Давайте быстренько вспомним, как нам обновить `master` и закачать выполненную работу."
            ],
            "afterMarkdowns": [
              "Здесь мы выполнили две команды, которые:",
              "",
              "* перебазировали нашу работу на новенький коммит, пришедший с удалённого репозитория, и",
              "* закачали свои наработки в удалённый репозиторий"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Текущая задача является достаточно обильной - здесь представлена общая схема выполнения:",
              "",
              "* Есть три фича-бранчи (фича-ветки) - `side1` `side2` и `side3`",
              "* Нам необходимо закачать каждую из них по очереди на удалённый репозиторий",
              "* При этом удалённый репозиторий хранит в себе какие-то наработки, которые также следует скачать к себе",
              "",
              ":O Сложно! Желаю вам удачи в выполнении этой непростой задачи."
            ]
          }
        }
      ]
    },
    "ja": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## 機能別のブランチ（フィーチャーブランチ）をマージする",
              "",
              "今や、あなたは`fetch`、`pull`、`push`を十分に使えるようになったでしょうから、そのスキルを新しい作業の流れで試してみましょう。",
              "",
              "大きなプロジェクトの開発者にとって、フィーチャーブランチ（`master`を除く）上で全ての作業を行い、完成したら一度でその作業を統合するというような流れが一般的です。これは前のレッスンの内容（他のブランチからリモートにプッシュされるような状況のところが）に似ていますが、ここではもう一歩踏み込んで解説しましょう。",
              "",
              "開発者は、`master`ブランチにいるときプッシュとプルしかしません -- `master`は常にリモート(`o/master`）に追従した状態のままにします。",
              "",
              "この作業の流れでは、私たちは二つのことを組み合わせています:",
              "",
              "* `master`にフィーチャーブランチの作業を統合し、",
              "* リモートへの`push`と`pull`を行う"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "`master`の更新と作業の反映の方法を手早く復習しましょう。"
            ],
            "afterMarkdowns": [
              "我々はここで二つのコマンドを動かしました:",
              "",
              "* リモートから新しいコミットを我々の作業にリベースし、",
              "* リモートに我々の作業を公開しました"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "このレベルはかなり難しいです -- ここに解答の一般的な道のりを示しておきます:",
              "",
              "* 三つのフィーチャーブランチ、`side1`、`side2`、`side3`があります。",
              "* この機能をそれぞれ、この順に、リモートにプッシュしてください。",
              "* リモートが更新されたなら、次はより良く作業を統合する方法を紹介しましょう。",
              "",
              ":O これはきつそうだ！このレベルを完了させることは大きな一歩となります。幸運を祈ります。"
            ]
          }
        }
      ]
    },
    "ko": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## feature 브랜치 병합하기",
              "",
              "이제 여러분은 fetch, pull, push하는데에 익숙해졌을겁니다. 연마한 기술들을 새로운 상황에서 시험 해봅시다.",
              "",
              "개발자들은 주로 큰 프로젝트를 개발할때 작업을 feature 브랜치(=토픽브랜치 / `master`브랜치가 아닌 작업을위해 임시로 만든 브랜치를 말합니다)들에 하고 준비가 되면 그 작업을 통합합니다. 이전 강의와 비슷한 모습인데(사이드 브랜치들을 원격저장소로 push한것), 여기서 한 단계 더 나아가 봅시다. ",
              "",
              "어떤 개발자들은 `master` 브랜치에 있을때만 push와 pull을 수행합니다 -- 이렇게하면 `master`는 항상 원격 브랜치 (`o/master`)의 상태와 항상 최신의 상태로 유지될 수 있습니다.",
              "",
              "이런 작업흐름은 두가지 작업을 같이하게됩니다 :",
              "",
              "* feature 브랜치의 작업을 master로 통합하는것과",
              "* 원격저장소에서 push하고 pull하는 작업입니다"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "다음을 보고 `master`를 갱신하고 작업을 push하는 방법을 다시 떠올려봅시다."
            ],
            "afterMarkdowns": [
              "여기서 우리는 두개의 명령어를 실행 했습니다 :",
              "",
              "* 우리의 작업을 원격 저장소의 새 커밋들로 리베이스한 후",
              "* 우리 작업을 원격저장소로 push했습니다."
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "이번 레벨은 꽤 덩치가 큽니다 -- 문제에대한 대략적인 설명을 해드리겠습니다 :",
              "",
              "* 세개의 feature 브랜치가 있습니다 -- `side1`, `side2` 그리고 `side3` 가 있습니다.",
              "* 각각의 브랜치를 순서에 맞게 원격 저장소로 push하고 싶습니다.",
              "* 원격 저장소가 최근에 갱신된적이 있기때문에 그 작업또한 포함시켜야 합니다.",
              "",
              ":O 이야 할게 많습니다! 행운을 빕니다, 이번 레벨은 많은걸 요구합니다."
            ]
          }
        }
      ]
    },
    "uk": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Мердж гілок з фічами",
              "",
              "Тепер, коли ти вже впевнено володієш засобами `pull` та `push`, час перевірити ці знання в новому процесі.",
              "",
              "Зазвичай розробники працюють над якимось фічами в окремій гілці (не в `master`), а потім, коли роботу закінчено, інтегрують її. Це схоже на попередній урок (де окремі гілки пушили у віддалений репозиторій), але тут буде ще один додатковий крок.",
              "",
              "Деякі розробники виконують push і pull лише в гілці `master` -- тож `master` завжди буде актуальним і синхронізованим з віддаленою гілкою (`o/master`).",
              "",
              "Отже для цього процесу ми об'єднуємо дві речі:",
              "",
              "* інтеграцію гілки з фічею в `master`, і",
              "* пул та пуш для синхронізації з віддаленим репозиторієм"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Пригадаймо коротко як оновити `master` і запушити свої зміни."
            ],
            "afterMarkdowns": [
              "Ми виконали дві команди, які:",
              "",
              "* заребейсили нашу роботу поверх віддалених комітів, і",
              "* опублікували наші зміни у віддаленому репозиторії"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Цей рівень доволі величенький -- ось, що треба буде зробити:",
              "",
              "* Є три гілки з фічами -- `side1` `side2` та `side3`",
              "* Ми хочемо запушити кожну з них по черзі у віддалений репозиторій",
              "* Віддалений репозиторій теж змінився, тож нам потрібно об'єднати всі ці зміни",
              "",
              ":O Чимале завдання! Успіху! Виконання цього рівня буде великим кроком."
            ]
          }
        }
      ]
    },
    "vi": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Sáp nhập các nhánh tính năng",
              "",
              "Giờ thì bạn đã quen thuộc với tìm nạp, kéo và đẩy, bây giờ chúng tôi sẽ kiểm tra kỹ năng của bạn với một quy trình làm việc mới.",
              "",
              "Trong các dự án lớn, các nhà phát triển thường làm việc trên các nhánh tính năng (được phân nhánh từ `master`) và chỉ thực hiện tích hợp sau khi công việc hoàn thành. Điều này tương tự như mô tả trong bài học trước (đẩy nhánh bên sang kho lưu trữ từ xa), nhưng chúng ta sẽ đi sâu hơn một chút trong phần này.",
              "",
              "Một vài nhà phát triển chỉ thực hiện đẩy và kéo khi ở trên nhánh `master` -- như vậy thì nhánh `master` luôn luôn được cập nhật với nhánh từ xa (`o/master`).",
              "",
              "Vậy nên với quy trình làm việc này chúng tôi đã kết hợp 2 việc:",
              "",
              "* tích hợp nhánh chức năng lên nhánh `master`, và",
              "* đẩy và kéo từ nhánh từ xa"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Hãy xem qua cách cập nhật nhánh `master` và đẩy lên nhánh từ xa hoạt động như thế nào."
            ],
            "afterMarkdowns": [
              "Ta thực thi 2 câu lệnh làm việc sau:",
              "",
              "* tái bố trí (`rebase`) thành quả của ta lên commit của nhánh từ xa, và",
              "* xuất bản thành quả của ta lên nhánh từ xa"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Cấp độ này khá là phức tạp đấy -- để hoàn thành thì hãy xem qua hướng dẫn cơ bản sau:",
              "",
              "* Có 3 nhánh chức năng là -- `side1` `side2` vả `side3`",
              "* Chúng tôi muốn bạn đẩy từng nhánh chức năng, theo thứ tự, lên nhánh từ xa",
              "* Nhánh từ xa cũng đã được cập nhật, nên ta cũng cần sát nhập thay đổi đó nữa",
              "",
              ":O khoai đây! Cố lên nhé, hoàn thành cấp độ này là lên trình nhiều lắm đấy."
            ]
          }
        }
      ]
    },
    "sl_SI": {
      "childViews": [
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "## Merganje funkcionalnih branchev",
              "",
              "Sedaj, ko se počutiš udobno s fetchanjem, pullanjem in pushanjem, preizkusimo ta znanja z novimi primeri.",
              "",
              "Za razvijalce na velikih projektih je pogosto, da delajo vse svoje stvari na funkcionalnih brancih (ne na `master`) in potem vključijo to delo, ko je končano. To je podobno prejšnjim lekcijam (kjer so bili pushani stranski branchi na oddaljen repo), a tu predstavljamo še en korak.",
              "",
              "Nekateri razvijaci samo pushajo in pullajo na `master` branchu -- zato `master` vedno ostane posodobljen z oddaljenim masterjem (`o/master`).",
              "",
              "Torej za tak primer uporabe, združimo dve stvari:",
              "",
              "* vključevanje dela funkcionalnih branchev na `master` in",
              "* pushanje in pullanje iz oddaljenega repota"
            ]
          }
        },
        {
          "type": "GitDemonstrationView",
          "options": {
            "beforeMarkdowns": [
              "Osvežimo si na hitro, kako posodobiti `master` in pushati delo."
            ],
            "afterMarkdowns": [
              "Izvedli smo dva ukaza, ki:",
              "",
              "* rebasata naše delo na nove commite iz oddaljenega repozitorija in",
              "* objavita naše delo na oddaljen repozitorij"
            ],
            "command": "git pull --rebase; git push",
            "beforeCommand": "git clone; git commit; git fakeTeamwork"
          }
        },
        {
          "type": "ModalAlert",
          "options": {
            "markdowns": [
              "Ta stopnja je kar zajetna -- tu je splošno ideja za rešitev:",
              "",
              "* Imamo tri branche -- `side1`, `side2` in `side3`",
              "* Želimo pushati vsako od teh funkcionalnosti po vrstnem redu na oddaljen repo",
              "* Oddaljen repo se je medtem posodobil, zato bomo morali vključiti tudi to delo",
              "",
              ":O Naporno! Srečno, končanje te stopnje je velik korak."
            ]
          }
        }
      ]
    }
  }
};
